﻿namespace _7_10
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtfo2 = new TextBox();
            button1 = new Button();
            listBox1 = new ListBox();
            button2 = new Button();
            show = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            SuspendLayout();
            // 
            // txtfo2
            // 
            txtfo2.Location = new Point(358, 47);
            txtfo2.Name = "txtfo2";
            txtfo2.Size = new Size(286, 23);
            txtfo2.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(112, 60);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(70, 123);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(120, 94);
            listBox1.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(59, 360);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 3;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // show
            // 
            show.Location = new Point(252, 135);
            show.Name = "show";
            show.Size = new Size(75, 23);
            show.TabIndex = 4;
            show.Text = "show";
            show.UseVisualStyleBackColor = true;
            show.Click += show_Click;
            // 
            // button3
            // 
            button3.Location = new Point(208, 194);
            button3.Name = "button3";
            button3.Size = new Size(205, 23);
            button3.TabIndex = 5;
            button3.Text = "show dialog with constract";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(208, 223);
            button4.Name = "button4";
            button4.Size = new Size(205, 23);
            button4.TabIndex = 6;
            button4.Text = "show with function";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(208, 252);
            button5.Name = "button5";
            button5.Size = new Size(205, 23);
            button5.TabIndex = 7;
            button5.Text = "show with modifers'";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(208, 281);
            button6.Name = "button6";
            button6.Size = new Size(205, 23);
            button6.TabIndex = 8;
            button6.Text = "show with staticvariblae\r\n";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(208, 310);
            button7.Name = "button7";
            button7.Size = new Size(205, 23);
            button7.TabIndex = 9;
            button7.Text = "show with  realopject\r\n";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(428, 194);
            button8.Name = "button8";
            button8.Size = new Size(205, 23);
            button8.TabIndex = 10;
            button8.Text = "show and send listbox\r\n";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(428, 223);
            button9.Name = "button9";
            button9.Size = new Size(205, 23);
            button9.TabIndex = 11;
            button9.Text = "show and send this form\r\n";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(428, 252);
            button10.Name = "button10";
            button10.Size = new Size(205, 23);
            button10.TabIndex = 12;
            button10.Text = "show ounsy\r\n\r\n";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(428, 281);
            button11.Name = "button11";
            button11.Size = new Size(205, 23);
            button11.TabIndex = 13;
            button11.Text = "show formal object";
            button11.UseVisualStyleBackColor = true;
          //  button11.Click += button11_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(show);
            Controls.Add(button2);
            Controls.Add(listBox1);
            Controls.Add(button1);
            Controls.Add(txtfo2);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtfo2;
        private Button button1;
        private ListBox listBox1;
        private Button button2;
        private Button show;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
    }
}