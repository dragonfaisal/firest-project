﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace _7_10
{
    public partial class Form1 : Form
    {
        public static string StaticVariable = ""; // متغير عام ثابت
        private Form2 _form2; // مرجع للفورم الثاني

        public Form1()
        {
            InitializeComponent();
        }

        public Form1(string name)
        {
            InitializeComponent();
            this.Text = name;
        }

        public Form1(Form2 form2)
        {
            InitializeComponent();
            _form2 = form2;
            txtfo1.Text = form2.GetName();
        }

        public Form1(ListBox listBox)
        {
            InitializeComponent();
            listBox1.Items.AddRange(listBox.Items);
        }

        public void SetValue(string name)
        {
            txtfo1.Text = name;
        }

        public string GetValue()
        {
            return txtfo1.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_form2 != null)
            {
                _form2.UpdateName(GetValue());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(txtfo1.Text);
        }
    }
}
