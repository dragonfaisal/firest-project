﻿using System;
using System.Windows.Forms;

namespace _7_10
{
    public partial class Form2 : Form
    {
        private Form1 _form1;

        public Form2()
        {
            InitializeComponent();
        }

        public string GetName()
        {
            return txtfo2.Text;
        }

        public void UpdateName(string name)
        {
            txtfo2.Text = name;
        }

        private void show_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1("التعامل مع الواجهات");
            form.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.SetValue(txtfo2.Text);
            form.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.SetValue(txtfo2.Text);
            form.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1.StaticVariable = txtfo2.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new Form1(txtfo2.Text).Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(listBox1);
            form.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(this);
            form.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (_form1 == null || _form1.IsDisposed)
            {
                _form1 = new Form1();
                _form1.Show();
            }
            else
            {
                _form1.BringToFront();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }
    }
}
