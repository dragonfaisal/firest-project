﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();

        }

        // تصاعدي
        private void sortanylistbox(ListBox l)
        {
            int t;
            int c = l.Items.Count;
            for (int i = 0; i < c; i++)

            {
                for (int j = i + 1; j < c; j++)
                {
                    int n1 = Convert.ToInt32(l.Items[i]),
                        n2 = Convert.ToInt32(l.Items[j]);
                    if (n1 > n2)
                    {
                        t = n1;
                        l.Items[i] = n2;
                        l.Items[j] = t;
                    }
                }
            }
        }

        // تنازلي
        private void sortanylistboxbiger(ListBox l)
        {
            int t;
            int c = l.Items.Count;
            for (int i = 0; i < c; i++)

            {
                for (int j = i + 1; j < c; j++)
                {
                    int n1 = Convert.ToInt32(l.Items[i]),
                        n2 = Convert.ToInt32(l.Items[j]);
                    if (n1 < n2)
                    {
                        t = n1;
                        l.Items[i] = n2;
                        l.Items[j] = t;
                    }
                }
            }
        }
        // للتحقق من ام المدخل رقماُ
        bool isnumoric(string element)
        {
            if (element == "")
                return false;
            for (int i = 0; i < element.Length; i++)
            {
                if (element[i] < 48 || element[i] > 57)
                    return false;
            }
            return true;
        }
        //للتحقق من تكرار العناصر في القائمه
        bool repeated(ListBox l, string s)
        {
            for (int i = 0; i < l.Items.Count; i++)
            {
                // MessageBox.Show(l.Items[i] + " " + s.ToString());

                if (l.Items[i].ToString() == s)
                    return true;
            }
            return false;
        }
        // < تفعيل وعدم تفعيل الزر  
        void setenabled()
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                button2.Enabled = true;
            }
            else
            {
                button2.Enabled = false;
            }
            //  button2.Enabled = listBox1.SelectedIndex > -1;
        }

        // عكس عناصر المصفوفه
        void revers(ListBox l)
        {
            for (int i = l.Items.Count - 1; i >= 0; i--)
            {
                l.Items.Add(l.Items[i]);
                l.Items.Remove(l.Items[i]);
            }
        }
        public void isnumber(KeyPressEventArgs e)
        {
            if((e.KeyChar < 48 || e.KeyChar > 57) &&( e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // تضعيف الحدث keypress للتكست بوكس الاول للتكستات كاامل
            textBox2.KeyPress += textBox1_KeyPress;
            textBox3.KeyPress += textBox1_KeyPress;
            textBox4.KeyPress += textBox1_KeyPress;
            textBox5.KeyPress += textBox1_KeyPress;
            textBox6.KeyPress += textBox1_KeyPress;
            textBox7.KeyPress += textBox1_KeyPress;
            //-----------------------------------------------------

            // ربط حدث تغيير التحديد بـ SetEnabled
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // تحديث حالة الزر عند التحميل لأول مرة
            setenabled();



            //--------------------------

            Height = groupBox1.Top + 50;
            //اضافه 10 قيم عشوائيه
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                //int n=(int)((100)* r.NextDouble());
                // double n = (100) * r.NextDouble();
                listBox1.Items.Add(r.Next(i, 100));
            }

        }


        private void button5_Click(object sender, EventArgs e)
        {
            //listBox1.Items.Remove(listBox1.SelectedIndex);
            if(listBox1.SelectedIndex != -1 )
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }
        // اضافه
        private void button1_Click(object sender, EventArgs e)
        {
            //  if(textBox1.Text.Trim() != "") 
            if (isnumoric(textBox1.Text.Trim()))
            {
                if (!repeated(listBox1, textBox1.Text))
                {
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                }


                else
                {
                    MessageBox.Show("الرقم موجود مسبقاً");
                    textBox1.Clear();
                    textBox1.Focus();

                }
            }
            else
            {
                MessageBox.Show("enter just number input");
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
            {
                // منع المدخل إذا لم يكن رقم أو Backspace
                e.Handled = true;
            }
        }
        // نقل العنصر المضلل
        private void button2_Click(object sender, EventArgs e)
        {

            //-----------------نقل عنصر عنصر--------
            //if (listBox1.SelectedItem != null)
            //{
            //    listBox2.Items.Add(listBox1.SelectedItem.ToString()); // إضافة العنصر إلى listBox2
            //    listBox1.Items.Remove(listBox1.SelectedItem);
            //    // listBox1.Items.Remove(listBox1.SelectedItems[0]);
            //    //listBox1.Items.Remove(listBox1.Items[listBox1.SelectedIndex]);
            //    //listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            //}
            //else
            //{
            //    MessageBox.Show("قم بتحديد العنصر ");
            //    listBox1.Focus();
            //}

            // التأكد من أن هناك عناصر مظللة
            if (listBox1.SelectedItems.Count > 0)
            {
                // تكرار لنقل العناصر المظللة إلى listBox2
                for (int i = listBox1.SelectedItems.Count - 1; i >= 0; i--)
                {
                    // إضافة العنصر المظلل إلى listBox2
                    listBox2.Items.Add(listBox1.SelectedItems[i]);

                    // إزالة العنصر من listBox1
                    listBox1.Items.Remove(listBox1.SelectedItems[i]);
                }
            }
            else
            {
                MessageBox.Show("قم بتحديد العنصر");
                listBox1.Focus();
            }


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            setenabled();
        }
        // نقل الكل
        private void button3_Click(object sender, EventArgs e)
        {
            int c = listBox1.Items.Count;
            for (int i = 0; i < c; i++)
            {
                if (!repeated(listBox2, listBox1.Items[0].ToString()))
                {
                    listBox2.Items.Add(listBox1.Items[0]);
                    listBox1.Items.Remove(listBox1.Items[0]);

                }
            }

            // طريقه اخرى
            // while (listBox1.Items.Count > 0)
            //{
            //  listBox2.Items.Add(listBox1.Items[0]);
            //listBox1.Items.Remove(listBox1.Items[0]);
            // }
        }
        // تنازلي
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sortanylistboxbiger(listBox1);
            //sortanylistbox((ListBox)sender);
        }
        // عكس عناصر المصفوفه
        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox1);
        }
        // زوجي
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            if (radioButton1.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 == 0)
                    {
                        listBox1.SelectedIndex = i;
                    }
                    
                }
            }
        }
        //فردي
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            if (radioButton2.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 != 0)
                    {
                        listBox1.SelectedIndex = i;
                    }
                    if (listBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("لأاتوجد عناصر فرديه");

                    }
                }
            }
        }
        // اولي
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            bool flag = true;
            if (radioButton3.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    int n = Convert.ToInt32(listBox1.Items[i]);
                    flag = true;
                    for (int j = 2; j < n; j++)
                    {
                        if (n % j == 0) 
                        {
                            flag = false;
                            break;

                        }
                        if(flag==true)
                        {
                            listBox1.SelectedIndex = i;
                        }
                        if(listBox1.SelectedIndex== -1)
                        {
                            MessageBox.Show("لا يوجد عناصر اوليه ");
                        }
                    }
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == "v")
            {
                Height = button4.Top + button4.Height + 480;
                button4.Text= "^";
            }
            else
            {
                button4.Text = "v";
                Height = groupBox1.Top + 50;
            }
        }

        // نقل العناصر نعكوسه
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            int n = listBox1.Items.Count;
            for (int i = 0; i < n; i++)
            {
                listBox2.Items.Add(listBox1.Items[listBox1.Items.Count - 1]);
                listBox1.Items.Remove(listBox1.Items[listBox1.Items.Count - 1]);
            }
        }
        //زر عمس العناصر القائمه الثانيه

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox2);
        }

        // تنازلي 
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            sortanylistboxbiger(listBox2);
           // radioButton4_CheckedChanged(listBox2, e);
        }
        // عمل تضليل على العنصر

        private void button9_Click(object sender, EventArgs e)
        {
            //listBox1.SelectedItems.Add(textBox2.Text);

            //listBox1.SelectedIndex= listBox1.Items.IndexOf(textBox2.Text);// هنا للتضليل على العتاصر المضافه وليس العتاصر المضافه عشوائياً

            string searchText = textBox2.Text;
            bool found = false;

            // التحقق من وجود النص المدخل في القائمة وتحديده
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (listBox1.Items[i].ToString() == searchText)
                {
                    listBox1.SelectedIndex = i;
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                MessageBox.Show("العنصر غير موجود في القائمة.");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //listBox1.SelectedItems.Remove(textBox3.Text);

           string  removeitemselected = textBox3.Text;
            bool found= false;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (listBox1.Items[i].ToString()== removeitemselected)
                {
                    listBox1.ClearSelected();
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                MessageBox.Show("العنصر لم يحدد");
            }
        }
        // عدد العناصر المضلله
        private void button13_Click(object sender, EventArgs e)
        {
            textBox6.Text=listBox1.SelectedItems.Count.ToString();
            if(listBox1.SelectedItems != null)
            {

            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Close();
        }
        // عدد العناصر

        private void button12_Click(object sender, EventArgs e)
        {
            int count = 0;
           // textBox5.Text = listBox1.Items.Count.ToString();
            if (listBox1.Items.Count >= 0)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    count++;
                }
                textBox5.Text= count.ToString();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(listBox2.SelectedIndex != -1)
            {
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);         

            }
            // بدون شرط
            listBox2.Items.Remove(listBox2.SelectedItem) ;
        }

        // حذف جميع العناصر من القائمه الاولى
        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
        // حف العناصر من القائمه الثانيه
        private void button7_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
           // listBox1.ClearSelected();

            if(listBox1.SelectedItems.Count >= 0)
            {
                listBox1.ClearSelected();
            }
            else
            {
                MessageBox.Show("قم بالتحديد");
            }
        }

        // تحديد جميع العناصر
        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (listBox1.Items.Count >= 0)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    listBox1.SelectedIndex = i;
                }
            }
            else
            {
                MessageBox.Show("لايوجد عناصر");
            }
            
        }
       // عدد العناصر المضلله
        private void button14_Click(object sender, EventArgs e)
        {
            textBox7.Text = (listBox1.Items.Count - listBox1.SelectedItems.Count).ToString(); 
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                int g = Convert.ToInt32(textBox4.Text);

                if (g >= 0 && g < listBox1.Items.Count)
                {
                    string selectedItem = listBox1.Items[g].ToString();
                    bool found = false;

                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        if (listBox1.Items[i].ToString() == selectedItem)
                        {
                            listBox1.SelectedIndex = i;
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                    {
                        MessageBox.Show("العنصر المدخل لا يوجد");
                    }
                }
                else
                {
                    MessageBox.Show("المؤشر خارج نطاق القائمة");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("يرجى إدخال رقم صحيح في مربع النص");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

